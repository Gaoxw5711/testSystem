export default {
  init: function () {
    return {
      reportData: [
        {
          name: '产品内测系统',
          date: '2017-11-2',
          principal: '爱谁谁'
        }, {
          name: '产品内测系统',
          date: '2017-11-2',
          principal: '爱谁谁'
        }, {
          name: '产品内测系统',
          date: '2017-11-2',
          principal: '爱谁谁'
        }, {
          name: '产品内测系统',
          date: '2017-11-2',
          principal: '爱谁谁'
        }
      ]
    }
  }
}
