import {
  getProjectList,
  removeProjectById,
  addProject,
  updateProject
} from '../../api/project'
import axios from 'axios';
export default {

  // 查询
  handleSearch() {
      this.pagination.current = 1;
      this.getTableData()
    },
    //设置分页大小
    handlePageSizeChange(pageSize) {
      this.pagination.pageSize = pageSize;
      this.getTableData();
    },
    //设置页码
    handleCurrentChange(current) {
      this.pagination.current = current;
      this.getTableData();
    },
    handleCloseAddDialog() {
      // this.classFrom = Object.assign({}, this.defaultClassFrom);
      this.dialogCreateProject = false;
      this.$refs.projectForm.resetFields();
    },
    getTableData() { //---------------------获取列表数据
      let para = {
        pageNum: this.pagination.current,
        pageSize: this.pagination.pageSize
          // ...this.filter
      };
      console.log(para);
      getProjectList(para).then((res) => {
        // console.log(res);
        this.tableData = res.data;
        this.pagination.total = res.data.length;
      });
    },
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          const params = Object.assign({}, this.projectForm);
          // console.log(params);
          addProject(params).then((res) => {
            console.log(res.data);
            this.$message({
              message: '新建成功！',
              type: 'success'
            });
            this.dialogCreateProject = false;
            this.$refs[formName].resetFields();
            this.getTableData();
          }).catch((err) => {
            this.$message({
              type: 'warning',
              message: '新建失败'
            });
            this.dialogCreateProject = false;
            this.$refs[formName].resetFields();
            console.log(err);
          });
          // alert('submit!');
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    delProject(scope) { //---------------------删除操作
      this.$confirm('此操作将删除选中项, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.removeProject(scope);
      }).catch(() => {
        this.$message({
          type: 'warning',
          message: '已取消删除'
        });
      });
    },
    enterinProject(scope) {
      console.log(scope);
    },
    removeProject(scope) {
      const params = {
        id: scope.row.id
      };
      console.log(scope);
      removeProjectById(params).then((res) => {
        this.getTableData();
        this.$message({
          type: 'info',
          message: '删除成功'
        });
      }).catch((err) => {
        console.log(err);
      })
    },

}