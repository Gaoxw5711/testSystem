export default {
	enterinProject() {
      console.log(this.$route.params.proName);
    },
}
